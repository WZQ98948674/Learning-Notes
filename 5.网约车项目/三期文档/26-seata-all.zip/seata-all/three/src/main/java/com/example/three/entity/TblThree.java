package com.example.three.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * tbl_three
 * @author 
 */
@Data
public class TblThree implements Serializable {
    private Integer id;

    private String name;

    private static final long serialVersionUID = 1L;
}