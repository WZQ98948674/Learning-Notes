package com.example.three;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreeApplicationTests {

    @Test
    void contextLoads() {
    }

}
