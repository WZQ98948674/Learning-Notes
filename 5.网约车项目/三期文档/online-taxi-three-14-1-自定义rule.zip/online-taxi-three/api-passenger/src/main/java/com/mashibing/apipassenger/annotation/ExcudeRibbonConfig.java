package com.mashibing.apipassenger.annotation;

public @interface ExcudeRibbonConfig {

}