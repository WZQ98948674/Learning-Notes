package com.mashibing.apilistenorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiListenOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
