package com.mashibing.servicevaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceValuationApplicationTests {

    @Test
    void contextLoads() {
    }

}
