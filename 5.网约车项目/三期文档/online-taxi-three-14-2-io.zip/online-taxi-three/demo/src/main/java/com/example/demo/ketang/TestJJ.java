package com.example.demo.ketang;

import java.math.BigDecimal;

public class TestJJ {

    public static void main(String[] args) {
        BigDecimal b = new BigDecimal(2.5);
//        BigDecimal c = new BigDecimal(1.2);
//        BigDecimal d = b.add(c);
        System.out.println(b+"---");

//        xx.xc;

        // 0 1 2 -----0.5
    }
}
