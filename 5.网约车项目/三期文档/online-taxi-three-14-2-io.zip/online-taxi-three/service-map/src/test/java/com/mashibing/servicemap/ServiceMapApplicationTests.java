package com.mashibing.servicemap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceMapApplicationTests {

    @Test
    void contextLoads() {
    }

}
