package com.mashibing.internalcommon.dto.servicepassengeruser;

public class T {
}
