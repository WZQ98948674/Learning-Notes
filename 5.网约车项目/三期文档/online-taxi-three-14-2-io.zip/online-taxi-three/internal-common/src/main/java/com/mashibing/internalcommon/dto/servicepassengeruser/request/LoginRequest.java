package com.mashibing.internalcommon.dto.servicepassengeruser.request;

import lombok.Data;

/**
 * @author yueyi2019
 */
@Data
public class LoginRequest {

    private String passengerPhone;

}