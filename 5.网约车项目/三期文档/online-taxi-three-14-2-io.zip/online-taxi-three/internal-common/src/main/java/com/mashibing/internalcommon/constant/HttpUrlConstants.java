package com.mashibing.internalcommon.constant;

public class HttpUrlConstants {

	public static final String SERVICE_SMS_URL = "http://service-sms";
	
	public static final String SERVICE_ORDER_URL = "http://service-order";

}