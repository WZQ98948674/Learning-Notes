package com.mashibing.internalcommon.util;

import com.mashibing.internalcommon.constant.IdentityConstant;
import com.mashibing.internalcommon.constant.RedisKeyPrefixConstant;

public class RedisKeyUtil {

}