package com.mashibing.lcnpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LcnPayApplicationTests {

    @Test
    void contextLoads() {
    }

}
