package com.mashibing.lcntm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LcnTmApplicationTests {

    @Test
    void contextLoads() {
    }

}
