package com.mashibing.internalcommon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalCommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
