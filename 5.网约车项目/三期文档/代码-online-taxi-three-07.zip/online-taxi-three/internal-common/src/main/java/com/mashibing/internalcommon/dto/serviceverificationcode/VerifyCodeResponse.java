package com.mashibing.internalcommon.dto.serviceverificationcode;

import lombok.Data;

@Data
public class VerifyCodeResponse {
	
	private String code;
}