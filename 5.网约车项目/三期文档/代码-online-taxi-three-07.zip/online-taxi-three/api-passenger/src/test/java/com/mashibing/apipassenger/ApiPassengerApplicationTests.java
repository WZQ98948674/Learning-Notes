package com.mashibing.apipassenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPassengerApplicationTests {

    @Test
    void contextLoads() {
    }

}
