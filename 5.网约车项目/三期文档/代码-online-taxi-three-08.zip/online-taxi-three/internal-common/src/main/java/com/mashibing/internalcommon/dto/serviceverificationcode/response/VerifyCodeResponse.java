package com.mashibing.internalcommon.dto.serviceverificationcode.response;

import lombok.Data;
/**
 * @author yueyi2019
 */
@Data
public class VerifyCodeResponse {
	
	private String code;
}