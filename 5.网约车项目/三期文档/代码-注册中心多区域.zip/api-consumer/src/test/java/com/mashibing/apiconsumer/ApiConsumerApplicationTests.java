package com.mashibing.apiconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
